package com.rose.blogwriterassistant

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.rose.blogwriterassistant.databinding.ActivityMainBinding
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val prefs by lazy {
        getSharedPreferences("blog_writer_settings", MODE_PRIVATE)
    }

    private var articleText: String = ""
    private val selectedImages = mutableListOf<Uri>()
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null

    private var leftWeight = 0.82f
    private var rightWeight = 1.18f
    private var settingsWeight = 0.78f
    private var chatWeight = 1.22f

    private var startX = 0f
    private var startLeft = 0.82f
    private var startY = 0f
    private var startSettings = 0.78f

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isEmpty()) {
            pendingFileCallback?.onReceiveValue(null)
            pendingFileCallback = null
            return@registerForActivityResult
        }

        selectedImages.clear()
        selectedImages.addAll(uris)

        uris.forEach { uri ->
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }

        pendingFileCallback?.onReceiveValue(uris.toTypedArray())
        pendingFileCallback = null

        binding.imageCountText.text = "선택 사진 ${selectedImages.size}장"
        binding.statusText.text = "사진 선택 완료"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        restoreSettings()
        configureWebView(binding.chatWeb, isBlog = false)
        configureWebView(binding.blogWeb, isBlog = true)
        setupButtons()
        setupDividers()
        loadSavedPages()
    }

    override fun onPause() {
        saveSettings()
        super.onPause()
    }

    private fun setupButtons() {
        binding.openGptButton.setOnClickListener {
            val url = normalizeUrl(
                binding.gptUrlInput.text.toString(),
                "https://chatgpt.com/"
            )
            binding.chatWeb.loadUrl(url)
            saveSettings()
        }

        binding.openBlogButton.setOnClickListener {
            val url = normalizeUrl(
                binding.blogUrlInput.text.toString(),
                "https://blog.naver.com/GoBlogWrite.naver"
            )
            binding.blogWeb.loadUrl(url)
            saveSettings()
        }

        binding.getGptTextButton.setOnClickListener {
            extractLastGptAnswer()
        }

        binding.insertBodyButton.setOnClickListener {
            insertArticleIntoBlog()
        }

        binding.selectImagesButton.setOnClickListener {
            imagePicker.launch(arrayOf("image/*"))
        }

        binding.startImageUploadButton.setOnClickListener {
            clickBlogImageButton()
        }

        binding.tempSaveButton.setOnClickListener {
            clickTemporarySave()
        }

        binding.saveSettingsButton.setOnClickListener {
            saveSettings()
            toast("설정을 저장했습니다.")
        }

        binding.toggleSettingsButton.setOnClickListener {
            toggleSettings()
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun configureWebView(webView: WebView, isBlog: Boolean) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.isVerticalScrollBarEnabled = true
        webView.isHorizontalScrollBarEnabled = true

        webView.setOnTouchListener { view, event ->
            view.parent?.requestDisallowInterceptTouchEvent(true)

            if (
                event.actionMasked == MotionEvent.ACTION_UP ||
                event.actionMasked == MotionEvent.ACTION_CANCEL
            ) {
                view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        if (isBlog) {
            webView.addJavascriptInterface(BlogBridge(), "BlogBridge")
        } else {
            webView.addJavascriptInterface(GptBridge(), "GptBridge")
        }

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (isBlog) {
                    prefs.edit().putString("last_blog_url", url).apply()
                    binding.statusText.text = "블로그 페이지 열기 완료"
                } else {
                    prefs.edit().putString("last_gpt_url", url).apply()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (!isBlog) return false

                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback

                if (selectedImages.isNotEmpty()) {
                    filePathCallback?.onReceiveValue(selectedImages.toTypedArray())
                    pendingFileCallback = null
                    binding.statusText.text = "선택한 사진을 블로그에 전달했습니다."
                    return true
                }

                imagePicker.launch(arrayOf("image/*"))
                return true
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun extractLastGptAnswer() {
        val script = """
            (function() {
                let nodes = Array.from(
                    document.querySelectorAll('[data-message-author-role="assistant"]')
                );

                if (!nodes.length) {
                    nodes = Array.from(document.querySelectorAll('.markdown.prose'));
                }

                const last = nodes[nodes.length - 1];
                const text = last ? (last.innerText || '').trim() : '';
                GptBridge.onText(text);
            })();
        """.trimIndent()

        binding.chatWeb.evaluateJavascript(script, null)
    }

    inner class GptBridge {
        @JavascriptInterface
        fun onText(text: String) {
            runOnUiThread {
                articleText = text.trim()

                if (articleText.isBlank()) {
                    binding.statusText.text = "GPT 마지막 답변을 찾지 못했습니다."
                    toast("가져올 GPT 글이 없습니다.")
                } else {
                    binding.previewText.text = articleText.take(1500)
                    binding.statusText.text = "GPT 글 가져오기 완료"
                    saveSettings()
                }
            }
        }
    }

    inner class BlogBridge {
        @JavascriptInterface
        fun onStatus(message: String) {
            runOnUiThread {
                binding.statusText.text = message
            }
        }
    }

    private fun insertArticleIntoBlog() {
        if (articleText.isBlank()) {
            toast("먼저 GPT 글을 가져와 주세요.")
            return
        }

        val escaped = JSONObject.quote(articleText)

        val script = """
            (function() {
                const text = $escaped;

                const candidates = [
                    ...document.querySelectorAll('[contenteditable="true"]'),
                    ...document.querySelectorAll('[role="textbox"]'),
                    ...document.querySelectorAll('textarea')
                ];

                const editor = candidates.find(function(e) {
                    const rect = e.getBoundingClientRect();
                    const description =
                        (e.getAttribute('data-placeholder') || '') + ' ' +
                        (e.getAttribute('aria-label') || '') + ' ' +
                        (e.getAttribute('placeholder') || '');

                    return rect.width > 150 &&
                           rect.height > 70 &&
                           !/제목|title/i.test(description);
                });

                if (!editor) return 'NO_EDITOR';

                editor.focus();

                if (editor.tagName === 'TEXTAREA') {
                    const setter = Object.getOwnPropertyDescriptor(
                        window.HTMLTextAreaElement.prototype,
                        'value'
                    ).set;

                    setter.call(editor, text);
                    editor.dispatchEvent(new Event('input', {bubbles:true}));
                    editor.dispatchEvent(new Event('change', {bubbles:true}));
                } else {
                    editor.innerHTML = '';

                    text.split(/\n\s*\n/).forEach(function(paragraph) {
                        const p = document.createElement('p');
                        p.textContent = paragraph.trim() || '\u00A0';
                        editor.appendChild(p);
                    });

                    editor.dispatchEvent(new InputEvent('input', {
                        bubbles: true,
                        inputType: 'insertText',
                        data: text
                    }));
                }

                editor.scrollIntoView({behavior:'smooth', block:'center'});
                return 'OK';
            })();
        """.trimIndent()

        binding.blogWeb.evaluateJavascript(script) { result ->
            if (result?.contains("NO_EDITOR") == true) {
                binding.statusText.text = "블로그 본문 영역을 찾지 못했습니다."
                toast("본문을 직접 한 번 누른 뒤 다시 실행해 주세요.")
            } else {
                binding.statusText.text = "블로그 본문 입력 완료"
            }
        }
    }

    private fun clickBlogImageButton() {
        val script = """
            (function() {
                const fileInput = document.querySelector('input[type="file"]');

                if (fileInput) {
                    fileInput.click();
                    return 'FILE_INPUT';
                }

                const nodes = Array.from(
                    document.querySelectorAll('button, a, [role="button"]')
                );

                const button = nodes.find(function(e) {
                    const text =
                        (e.innerText || e.textContent || '') + ' ' +
                        (e.getAttribute('aria-label') || '') + ' ' +
                        (e.getAttribute('title') || '');

                    return /사진|이미지|photo|image/i.test(text);
                });

                if (!button) return 'NO_BUTTON';

                button.scrollIntoView({behavior:'smooth', block:'center'});
                button.click();
                return 'BUTTON';
            })();
        """.trimIndent()

        binding.blogWeb.evaluateJavascript(script) { result ->
            if (result?.contains("NO_BUTTON") == true) {
                toast("사진 버튼을 찾지 못했습니다. 오른쪽에서 사진 버튼을 직접 눌러 주세요.")
                binding.statusText.text = "사진 버튼 감지 실패"
            } else {
                binding.statusText.text = "사진 업로드 창 열기 시도"
            }
        }
    }

    private fun clickTemporarySave() {
        val script = """
            (function() {
                const nodes = Array.from(
                    document.querySelectorAll('button, a, [role="button"]')
                );

                const target = nodes.find(function(e) {
                    const text =
                        (e.innerText || e.textContent || '') + ' ' +
                        (e.getAttribute('aria-label') || '') + ' ' +
                        (e.getAttribute('title') || '');

                    return /임시\s*저장|임시저장/i.test(text);
                });

                if (!target) return 'NOT_FOUND';

                target.scrollIntoView({behavior:'smooth', block:'center'});
                target.click();
                return 'OK';
            })();
        """.trimIndent()

        binding.blogWeb.evaluateJavascript(script) { result ->
            if (result?.contains("NOT_FOUND") == true) {
                toast("임시저장 버튼을 찾지 못했습니다. 직접 눌러 주세요.")
                binding.statusText.text = "임시저장 버튼 감지 실패"
            } else {
                binding.statusText.text = "임시저장 실행"
            }
        }
    }

    private fun setupDividers() {
        binding.verticalDivider.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX
                    startLeft = leftWeight
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val width = max(binding.root.width, 1)
                    val delta = (event.rawX - startX) / width * 2f

                    leftWeight = min(1.60f, max(0.40f, startLeft + delta))
                    rightWeight = 2f - leftWeight

                    applyWeights()
                    true
                }

                MotionEvent.ACTION_UP -> {
                    saveSettings()
                    true
                }

                else -> false
            }
        }

        binding.horizontalDivider.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = event.rawY
                    startSettings = settingsWeight
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val height = max(binding.leftColumn.height, 1)
                    val delta = (event.rawY - startY) / height * 2f

                    settingsWeight =
                        min(1.70f, max(0.30f, startSettings + delta))
                    chatWeight = 2f - settingsWeight

                    applyWeights()
                    true
                }

                MotionEvent.ACTION_UP -> {
                    saveSettings()
                    true
                }

                else -> false
            }
        }
    }

    private fun toggleSettings() {
        val collapsed = binding.settingsScroll.visibility == View.GONE

        if (collapsed) {
            binding.settingsScroll.visibility = View.VISIBLE
            binding.toggleSettingsButton.text = "◀ 설정 접기"

            (binding.settingsScroll.layoutParams as LinearLayout.LayoutParams).weight =
                settingsWeight
            (binding.chatWeb.layoutParams as LinearLayout.LayoutParams).weight =
                chatWeight
        } else {
            binding.settingsScroll.visibility = View.GONE
            binding.toggleSettingsButton.text = "▶ 설정 펼치기"

            (binding.chatWeb.layoutParams as LinearLayout.LayoutParams).weight =
                1.90f
        }

        prefs.edit().putBoolean("collapsed", !collapsed).apply()
        binding.leftColumn.requestLayout()
    }

    private fun applyWeights() {
        (binding.leftColumn.layoutParams as LinearLayout.LayoutParams).weight =
            leftWeight
        (binding.blogWeb.layoutParams as LinearLayout.LayoutParams).weight =
            rightWeight

        if (binding.settingsScroll.visibility != View.GONE) {
            (binding.settingsScroll.layoutParams as LinearLayout.LayoutParams).weight =
                settingsWeight
            (binding.chatWeb.layoutParams as LinearLayout.LayoutParams).weight =
                chatWeight
        }

        binding.root.requestLayout()
    }

    private fun restoreSettings() {
        binding.gptUrlInput.setText(
            prefs.getString("gpt_url", "https://chatgpt.com/")
        )

        binding.blogUrlInput.setText(
            prefs.getString(
                "blog_url",
                "https://blog.naver.com/GoBlogWrite.naver"
            )
        )

        articleText = prefs.getString("article_text", "") ?: ""

        if (articleText.isNotBlank()) {
            binding.previewText.text = articleText.take(1500)
        }

        leftWeight =
            prefs.getFloat("left_weight", 0.82f).coerceIn(0.40f, 1.60f)
        rightWeight = 2f - leftWeight

        settingsWeight =
            prefs.getFloat("settings_weight", 0.78f).coerceIn(0.30f, 1.70f)
        chatWeight = 2f - settingsWeight
    }

    private fun saveSettings() {
        prefs.edit()
            .putString(
                "gpt_url",
                normalizeUrl(
                    binding.gptUrlInput.text.toString(),
                    "https://chatgpt.com/"
                )
            )
            .putString(
                "blog_url",
                normalizeUrl(
                    binding.blogUrlInput.text.toString(),
                    "https://blog.naver.com/GoBlogWrite.naver"
                )
            )
            .putString("article_text", articleText)
            .putFloat("left_weight", leftWeight)
            .putFloat("settings_weight", settingsWeight)
            .apply()
    }

    private fun loadSavedPages() {
        binding.chatWeb.loadUrl(
            prefs.getString(
                "last_gpt_url",
                prefs.getString("gpt_url", "https://chatgpt.com/")
            ) ?: "https://chatgpt.com/"
        )

        binding.blogWeb.loadUrl(
            prefs.getString(
                "last_blog_url",
                prefs.getString(
                    "blog_url",
                    "https://blog.naver.com/GoBlogWrite.naver"
                )
            ) ?: "https://blog.naver.com/GoBlogWrite.naver"
        )

        applyWeights()

        if (prefs.getBoolean("collapsed", false)) {
            binding.settingsScroll.visibility = View.GONE
            binding.toggleSettingsButton.text = "▶ 설정 펼치기"
        }
    }

    private fun normalizeUrl(value: String, fallback: String): String {
        val text = value.trim()

        return when {
            text.isBlank() -> fallback
            text.startsWith("http://") || text.startsWith("https://") -> text
            else -> "https://$text"
        }
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            binding.blogWeb.canGoBack() -> binding.blogWeb.goBack()
            binding.chatWeb.canGoBack() -> binding.chatWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
