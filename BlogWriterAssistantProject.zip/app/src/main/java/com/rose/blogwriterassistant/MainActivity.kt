package com.rose.blogwriterassistant

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.rose.blogwriterassistant.databinding.ActivityMainBinding
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("blog_writer", MODE_PRIVATE) }

    private var articleText = ""
    private val selectedImages = mutableListOf<Uri>()
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null

    private var leftWeight = 0.8f
    private var rightWeight = 1.2f
    private var settingsWeight = 0.72f
    private var chatWeight = 1.28f
    private var startX = 0f
    private var startLeft = 0.8f
    private var startY = 0f
    private var startSettings = 0.72f

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        selectedImages.clear()
        selectedImages.addAll(uris)
        uris.forEach { uri ->
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }
        pendingFileCallback?.onReceiveValue(selectedImages.toTypedArray())
        pendingFileCallback = null
        binding.imageCountText.text = "선택 사진 ${selectedImages.size}장"
        binding.statusText.text = "사진 선택 완료"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        restore()
        configureWebView(binding.chatWeb, false)
        configureWebView(binding.blogWeb, true)
        bindButtons()
        setupDividers()
        loadPages()
    }

    override fun onPause() {
        save()
        super.onPause()
    }

    private fun bindButtons() {
        binding.openGptButton.setOnClickListener {
            binding.chatWeb.loadUrl(normalize(binding.gptUrlInput.text.toString(), "https://chatgpt.com/"))
            save()
        }

        binding.openBlogButton.setOnClickListener {
            binding.blogWeb.loadUrl(
                normalize(binding.blogUrlInput.text.toString(), "https://blog.naver.com/GoBlogWrite.naver")
            )
            save()
        }

        binding.getTextButton.setOnClickListener { extractLastGptAnswer() }
        binding.insertTextButton.setOnClickListener { insertTextToBlog() }
        binding.selectImagesButton.setOnClickListener {
            imagePicker.launch(arrayOf("image/*"))
        }
        binding.uploadImagesButton.setOnClickListener { clickPhotoButton() }
        binding.distributeButton.setOnClickListener { distributeImages() }
        binding.tempSaveButton.setOnClickListener { clickTempSave() }
        binding.toggleSettingsButton.setOnClickListener { toggleSettings() }
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun configureWebView(webView: WebView, isBlog: Boolean) {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.setOnTouchListener { view, event ->
            view.parent?.requestDisallowInterceptTouchEvent(true)
            if (event.actionMasked == MotionEvent.ACTION_UP ||
                event.actionMasked == MotionEvent.ACTION_CANCEL) {
                view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }

        if (isBlog) webView.addJavascriptInterface(BlogBridge(), "BlogBridge")
        else webView.addJavascriptInterface(GptBridge(), "GptBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (isBlog) prefs.edit().putString("last_blog", url).apply()
                else prefs.edit().putString("last_gpt", url).apply()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback

                if (selectedImages.isNotEmpty()) {
                    filePathCallback?.onReceiveValue(selectedImages.toTypedArray())
                    pendingFileCallback = null
                    binding.statusText.text = "선택 사진 전달 완료"
                } else {
                    imagePicker.launch(arrayOf("image/*"))
                }
                return true
            }
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
    }

    private fun extractLastGptAnswer() {
        val js = """
            (function() {
              let nodes = Array.from(document.querySelectorAll('[data-message-author-role="assistant"]'));
              if (!nodes.length) nodes = Array.from(document.querySelectorAll('.markdown.prose'));
              const last = nodes[nodes.length - 1];
              GptBridge.onText(last ? (last.innerText || '').trim() : '');
            })();
        """.trimIndent()
        binding.chatWeb.evaluateJavascript(js, null)
    }

    inner class GptBridge {
        @JavascriptInterface
        fun onText(text: String) {
            runOnUiThread {
                articleText = text.trim()
                if (articleText.isBlank()) {
                    toast("가져올 GPT 글이 없습니다.")
                } else {
                    binding.previewText.text = articleText.take(1200)
                    binding.statusText.text = "GPT 글 가져오기 완료"
                    save()
                }
            }
        }
    }

    private fun insertTextToBlog() {
        if (articleText.isBlank()) {
            toast("먼저 GPT 글을 가져와 주세요.")
            return
        }

        val escaped = JSONObject.quote(articleText)
        val js = """
            (function() {
              const text = $escaped;
              const editors = [
                ...document.querySelectorAll('[contenteditable="true"]'),
                ...document.querySelectorAll('[role="textbox"]'),
                ...document.querySelectorAll('textarea')
              ];

              const editor = editors.find(e => {
                const r = e.getBoundingClientRect();
                const hint = (e.getAttribute('aria-label') || '') + ' ' +
                             (e.getAttribute('placeholder') || '');
                return r.width > 150 && r.height > 80 && !/제목|title/i.test(hint);
              });

              if (!editor) return 'NO_EDITOR';
              editor.focus();

              if (editor.tagName === 'TEXTAREA') {
                const setter = Object.getOwnPropertyDescriptor(
                    window.HTMLTextAreaElement.prototype, 'value'
                ).set;
                setter.call(editor, text);
                editor.dispatchEvent(new Event('input', {bubbles:true}));
              } else {
                editor.innerHTML = '';
                text.split(/\n\s*\n/).forEach(paragraph => {
                    const p = document.createElement('p');
                    p.textContent = paragraph.trim() || '\u00A0';
                    editor.appendChild(p);
                });
                editor.dispatchEvent(new InputEvent('input', {bubbles:true}));
              }

              editor.scrollIntoView({behavior:'smooth', block:'center'});
              return 'OK';
            })();
        """.trimIndent()

        binding.blogWeb.evaluateJavascript(js) { result ->
            if (result?.contains("NO_EDITOR") == true) {
                toast("본문을 한 번 눌러 커서를 둔 뒤 다시 눌러 주세요.")
            } else {
                binding.statusText.text = "본문 입력 완료"
            }
        }
    }

    private fun clickPhotoButton() {
        if (selectedImages.isEmpty()) {
            toast("먼저 사진을 선택해 주세요.")
            return
        }

        val js = """
            (function() {
              const file = document.querySelector('input[type="file"]');
              if (file) { file.click(); return 'FILE'; }

              const nodes = Array.from(document.querySelectorAll(
                'button, a, [role="button"], [aria-label], [title]'
              ));
              const target = nodes.find(e => {
                const text = (e.innerText || e.textContent || '') + ' ' +
                             (e.getAttribute('aria-label') || '') + ' ' +
                             (e.getAttribute('title') || '');
                return /사진|이미지|photo|image/i.test(text);
              });

              if (!target) return 'NO_BUTTON';
              target.click();
              return 'OK';
            })();
        """.trimIndent()

        binding.blogWeb.evaluateJavascript(js) { result ->
            if (result?.contains("NO_BUTTON") == true) {
                toast("사진 버튼을 직접 한 번 눌러 주세요.")
            } else {
                binding.statusText.text = "사진 업로드 시작"
            }
        }
    }

    private fun distributeImages() {
        val js = """
            (function() {
              const editor = Array.from(document.querySelectorAll(
                '[contenteditable="true"], [role="textbox"]'
              )).find(e => {
                const r = e.getBoundingClientRect();
                return r.width > 150 && r.height > 80;
              });

              if (!editor) return 'NO_EDITOR';

              const paragraphs = Array.from(editor.querySelectorAll('p'))
                .filter(e => (e.innerText || '').trim().length > 0);

              const blocks = Array.from(editor.querySelectorAll('figure, img'))
                .map(e => e.closest('figure') || e)
                .filter((e, i, arr) => arr.indexOf(e) === i);

              if (!paragraphs.length || !blocks.length) return 'NO_ITEMS';

              const step = Math.max(1, Math.floor(paragraphs.length / blocks.length));

              blocks.forEach((block, index) => {
                const p = paragraphs[Math.min(paragraphs.length - 1, index * step)];
                if (p && p.parentNode) p.parentNode.insertBefore(block, p.nextSibling);
              });

              editor.dispatchEvent(new InputEvent('input', {bubbles:true}));
              return 'OK';
            })();
        """.trimIndent()

        binding.blogWeb.evaluateJavascript(js) { result ->
            when {
                result?.contains("NO_EDITOR") == true ->
                    toast("본문 편집 영역을 찾지 못했습니다.")
                result?.contains("NO_ITEMS") == true ->
                    toast("업로드된 사진 또는 문단을 찾지 못했습니다.")
                else ->
                    binding.statusText.text = "사진 문단 분산 시도 완료"
            }
        }
    }

    private fun clickTempSave() {
        val js = """
            (function() {
              const nodes = Array.from(document.querySelectorAll(
                'button, a, [role="button"]'
              ));

              const target = nodes.find(e => {
                const text = (e.innerText || e.textContent || '') + ' ' +
                             (e.getAttribute('aria-label') || '');
                return /임시\s*저장|임시저장/i.test(text);
              });

              if (!target) return 'NO_SAVE';
              target.click();
              return 'OK';
            })();
        """.trimIndent()

        binding.blogWeb.evaluateJavascript(js) { result ->
            if (result?.contains("NO_SAVE") == true) {
                toast("임시저장 버튼을 직접 한 번 눌러 주세요.")
            } else {
                binding.statusText.text = "임시저장 실행"
            }
        }
    }

    inner class BlogBridge {
        @JavascriptInterface
        fun onStatus(message: String) {
            runOnUiThread { binding.statusText.text = message }
        }
    }

    private fun setupDividers() {
        binding.verticalDivider.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX
                    startLeft = leftWeight
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val width = max(binding.root.width, 1)
                    val delta = (event.rawX - startX) / width * 2f
                    leftWeight = min(1.6f, max(0.4f, startLeft + delta))
                    rightWeight = 2f - leftWeight
                    applyWeights()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    save()
                    true
                }
                else -> false
            }
        }

        binding.horizontalDivider.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = event.rawY
                    startSettings = settingsWeight
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val height = max(binding.leftColumn.height, 1)
                    val delta = (event.rawY - startY) / height * 2f
                    settingsWeight = min(1.7f, max(0.3f, startSettings + delta))
                    chatWeight = 2f - settingsWeight
                    applyWeights()
                    true
                }
                MotionEvent.ACTION_UP -> {
                    save()
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleSettings() {
        val collapsed = binding.settingsScroll.visibility == View.GONE
        if (collapsed) {
            binding.settingsScroll.visibility = View.VISIBLE
            binding.toggleSettingsButton.text = "◀ 설정 접기"
            (binding.settingsScroll.layoutParams as LinearLayout.LayoutParams).weight = settingsWeight
            (binding.chatWeb.layoutParams as LinearLayout.LayoutParams).weight = chatWeight
        } else {
            binding.settingsScroll.visibility = View.GONE
            binding.toggleSettingsButton.text = "▶ 설정 펼치기"
            (binding.chatWeb.layoutParams as LinearLayout.LayoutParams).weight = 1.84f
        }
        prefs.edit().putBoolean("collapsed", !collapsed).apply()
    }

    private fun applyWeights() {
        (binding.leftColumn.layoutParams as LinearLayout.LayoutParams).weight = leftWeight
        (binding.blogWeb.layoutParams as LinearLayout.LayoutParams).weight = rightWeight

        if (binding.settingsScroll.visibility != View.GONE) {
            (binding.settingsScroll.layoutParams as LinearLayout.LayoutParams).weight = settingsWeight
            (binding.chatWeb.layoutParams as LinearLayout.LayoutParams).weight = chatWeight
        }
        binding.root.requestLayout()
    }

    private fun restore() {
        binding.gptUrlInput.setText(prefs.getString("gpt_url", "https://chatgpt.com/"))
        binding.blogUrlInput.setText(
            prefs.getString("blog_url", "https://blog.naver.com/GoBlogWrite.naver")
        )
        articleText = prefs.getString("article", "") ?: ""
        if (articleText.isNotBlank()) binding.previewText.text = articleText.take(1200)

        leftWeight = prefs.getFloat("left_weight", 0.8f)
        rightWeight = 2f - leftWeight
        settingsWeight = prefs.getFloat("settings_weight", 0.72f)
        chatWeight = 2f - settingsWeight
    }

    private fun save() {
        prefs.edit()
            .putString("gpt_url", normalize(binding.gptUrlInput.text.toString(), "https://chatgpt.com/"))
            .putString(
                "blog_url",
                normalize(binding.blogUrlInput.text.toString(), "https://blog.naver.com/GoBlogWrite.naver")
            )
            .putString("article", articleText)
            .putFloat("left_weight", leftWeight)
            .putFloat("settings_weight", settingsWeight)
            .apply()
    }

    private fun loadPages() {
        binding.chatWeb.loadUrl(
            prefs.getString("last_gpt", prefs.getString("gpt_url", "https://chatgpt.com/"))
                ?: "https://chatgpt.com/"
        )
        binding.blogWeb.loadUrl(
            prefs.getString(
                "last_blog",
                prefs.getString("blog_url", "https://blog.naver.com/GoBlogWrite.naver")
            ) ?: "https://blog.naver.com/GoBlogWrite.naver"
        )

        applyWeights()

        if (prefs.getBoolean("collapsed", false)) {
            binding.settingsScroll.visibility = View.GONE
            binding.toggleSettingsButton.text = "▶ 설정 펼치기"
        }
    }

    private fun normalize(value: String, fallback: String): String {
        val text = value.trim()
        return when {
            text.isBlank() -> fallback
            text.startsWith("http://") || text.startsWith("https://") -> text
            else -> "https://$text"
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            binding.blogWeb.canGoBack() -> binding.blogWeb.goBack()
            binding.chatWeb.canGoBack() -> binding.chatWeb.goBack()
            else -> super.onBackPressed()
        }
    }
}
